`timescale 1ns/1ps

module tb_contador_top;

    reg CLOCK_50;
    reg KEY_RST_N;
    reg KEY_PAUSA_N;
    reg SW_VEL;
    reg SW_ASC;
    reg SW_DESC;

    wire [6:0] HEX0, HEX1, HEX2, HEX3;
    wire [9:0] LEDR;

    contador_top #(
        .LIM_LENTO(26'd19),
        .LIM_RAPIDO(26'd4),
        .DB_LIMIT(19'd9)
    ) dut (
        .CLOCK_50(CLOCK_50),
        .KEY_RST_N(KEY_RST_N),
        .KEY_PAUSA_N(KEY_PAUSA_N),
        .SW_VEL(SW_VEL),
        .SW_ASC(SW_ASC),
        .SW_DESC(SW_DESC),
        .HEX0(HEX0),
        .HEX1(HEX1),
        .HEX2(HEX2),
        .HEX3(HEX3),
        .LEDR(LEDR)
    );

    initial CLOCK_50 = 1'b0;
    always #10 CLOCK_50 = ~CLOCK_50;

    always @(dut.valor)
        $display("t=%0t ps  valor=%0d  estado=%0d  vel=%b", $time, dut.valor, dut.estado, SW_VEL);

    initial begin
        $dumpfile("tb_contador_top.vcd");
        $dumpvars(0, tb_contador_top);

        KEY_RST_N   = 1'b0;
        KEY_PAUSA_N = 1'b1;
        SW_VEL      = 1'b0;
        SW_ASC      = 1'b0;
        SW_DESC     = 1'b0;

        #100 KEY_RST_N = 1'b1;

        $display("--- Ascendente lento (tick cada 20 ciclos) ---");
        SW_ASC = 1'b1;
        #(20*20*5);

        $display("--- Ascendente rapido (tick cada 5 ciclos) ---");
        SW_VEL = 1'b1;
        #(20*5*5);

        $display("--- Pausa con rebote simulado ---");
        SW_ASC = 1'b0;
        #100;
        KEY_PAUSA_N = 1'b0; #30;
        KEY_PAUSA_N = 1'b1; #20;
        KEY_PAUSA_N = 1'b0; #40;
        KEY_PAUSA_N = 1'b1; #20;
        KEY_PAUSA_N = 1'b0;
        #1000;
        KEY_PAUSA_N = 1'b1;
        #1000;

        $display("--- Descendente rapido ---");
        SW_DESC = 1'b1;
        #(20*5*20);

        $display("--- Reset ---");
        KEY_RST_N = 1'b0;
        #100;
        KEY_RST_N = 1'b1;
        #200;

        $finish;
    end

endmodule
