`timescale 1ns/1ps

module tick_gen #(
    parameter [25:0] LIM_LENTO  = 26'd49_999_999,
    parameter [25:0] LIM_RAPIDO = 26'd4_999_999
)(
    input  wire clk,
    input  wire rst,
    input  wire en,
    input  wire vel_sel,
    output reg  tick_out
);

    reg [25:0] div_cnt;

    wire [25:0] limite = vel_sel ? LIM_RAPIDO : LIM_LENTO;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            div_cnt  <= 26'd0;
            tick_out <= 1'b0;
        end
        else if (!en) begin
            div_cnt  <= 26'd0;
            tick_out <= 1'b0;
        end
        else if (div_cnt >= limite) begin
            div_cnt  <= 26'd0;
            tick_out <= 1'b1;
        end
        else begin
            div_cnt  <= div_cnt + 26'd1;
            tick_out <= 1'b0;
        end
    end

endmodule
