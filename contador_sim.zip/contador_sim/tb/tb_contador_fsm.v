`timescale 1ns/1ps

module tb_contador_fsm;

    reg clk;
    reg rst;
    reg tick_in;
    reg pausa_p;
    reg sw_asc;
    reg sw_desc;

    wire signed [8:0] valor;
    wire [1:0]        estado;
    wire [6:0]        HEX0, HEX1, HEX2, HEX3;

    integer errores;
    integer esperado;
    integer i;

    contador_fsm dut (
        .clk(clk),
        .rst(rst),
        .tick_in(tick_in),
        .pausa_p(pausa_p),
        .sw_asc(sw_asc),
        .sw_desc(sw_desc),
        .valor(valor),
        .estado(estado)
    );

    display_9bit u_disp (
        .dato(valor),
        .HEX0(HEX0),
        .HEX1(HEX1),
        .HEX2(HEX2),
        .HEX3(HEX3)
    );

    initial clk = 1'b0;
    always #10 clk = ~clk;

    function integer seg2dig;
        input [6:0] s;
        begin
            case (s)
                7'b1000000: seg2dig = 0;
                7'b1111001: seg2dig = 1;
                7'b0100100: seg2dig = 2;
                7'b0110000: seg2dig = 3;
                7'b0011001: seg2dig = 4;
                7'b0010010: seg2dig = 5;
                7'b0000010: seg2dig = 6;
                7'b1111000: seg2dig = 7;
                7'b0000000: seg2dig = 8;
                7'b0010000: seg2dig = 9;
                default:    seg2dig = -1;
            endcase
        end
    endfunction

    task dar_tick;
        begin
            @(negedge clk) tick_in = 1'b1;
            @(negedge clk) tick_in = 1'b0;
        end
    endtask

    task revisar_valor;
        input integer esp;
        input [8*24-1:0] etiqueta;
        begin
            if (valor !== esp) begin
                $display("ERROR [%0s] valor=%0d, esperado=%0d (t=%0t ps)", etiqueta, valor, esp, $time);
                errores = errores + 1;
            end
        end
    endtask

    task revisar_display;
        integer mostrado;
        begin
            #1;
            mostrado = seg2dig(HEX2)*100 + seg2dig(HEX1)*10 + seg2dig(HEX0);
            if (HEX3 == 7'b0111111)
                mostrado = -mostrado;
            else if (HEX3 != 7'b1111111) begin
                $display("ERROR display: HEX3 invalido %b", HEX3);
                errores = errores + 1;
            end
            if (mostrado !== valor) begin
                $display("ERROR display: muestra %0d pero valor=%0d", mostrado, valor);
                errores = errores + 1;
            end
        end
    endtask

    initial begin
        $dumpfile("tb_contador_fsm.vcd");
        $dumpvars(0, tb_contador_fsm);

        errores = 0;
        rst     = 1'b1;
        tick_in = 1'b0;
        pausa_p = 1'b0;
        sw_asc  = 1'b0;
        sw_desc = 1'b0;

        repeat (3) @(negedge clk);
        rst = 1'b0;

        $display("--- Prueba 1: reset ---");
        revisar_valor(0, "reset");
        if (estado !== 2'd0) begin
            $display("ERROR: estado tras reset = %0d", estado);
            errores = errores + 1;
        end

        $display("--- Prueba 2: ticks en pausa no cambian el valor ---");
        for (i = 0; i < 5; i = i + 1) dar_tick;
        revisar_valor(0, "pausa");

        $display("--- Prueba 3: ascendente de 0 a 255 y salto a -256 ---");
        @(negedge clk) sw_asc = 1'b1;
        @(negedge clk);
        esperado = 0;
        for (i = 0; i < 300; i = i + 1) begin
            dar_tick;
            esperado = (esperado == 255) ? -256 : esperado + 1;
            revisar_valor(esperado, "ascendente");
            revisar_display;
            if (valor == 255)  $display("  llego a 255 (t=%0t ps)", $time);
            if (valor == -256) $display("  salto a -256 (t=%0t ps)", $time);
        end

        $display("--- Prueba 4: pausa (switches abajo) ---");
        @(negedge clk) sw_asc = 1'b0;
        @(negedge clk) pausa_p = 1'b1;
        @(negedge clk) pausa_p = 1'b0;
        for (i = 0; i < 10; i = i + 1) dar_tick;
        revisar_valor(esperado, "pausa");
        $display("  valor congelado en %0d", valor);

        $display("--- Prueba 5: descendente con salto de -256 a 255 ---");
        @(negedge clk) sw_desc = 1'b1;
        @(negedge clk);
        for (i = 0; i < 400; i = i + 1) begin
            dar_tick;
            esperado = (esperado == -256) ? 255 : esperado - 1;
            revisar_valor(esperado, "descendente");
            revisar_display;
            if (valor == -256) $display("  llego a -256 (t=%0t ps)", $time);
            if (valor == 255 && esperado == 255) $display("  salto a 255 (t=%0t ps)", $time);
        end

        $display("--- Prueba 6: prioridad ASC sobre DESC ---");
        @(negedge clk) sw_asc = 1'b1;
        @(negedge clk);
        if (estado !== 2'd1) begin
            $display("ERROR: con ambos switches el estado deberia ser ASC");
            errores = errores + 1;
        end
        dar_tick;
        esperado = (esperado == 255) ? -256 : esperado + 1;
        revisar_valor(esperado, "prioridad");

        $display("--- Prueba 7: reset a mitad de la cuenta ---");
        @(negedge clk) rst = 1'b1;
        @(negedge clk) rst = 1'b0;
        revisar_valor(0, "reset final");

        $display("=========================================");
        if (errores == 0)
            $display(" TODAS LAS PRUEBAS PASARON");
        else
            $display(" FALLARON %0d VERIFICACIONES", errores);
        $display("=========================================");
        $finish;
    end

endmodule
