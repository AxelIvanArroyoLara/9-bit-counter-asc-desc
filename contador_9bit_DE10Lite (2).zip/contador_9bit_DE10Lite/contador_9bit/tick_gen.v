module tick_gen (
    input  wire clk,
    input  wire rst,
    input  wire en,
    input  wire vel_sel,
	 input wire vel_sel2,
	 input wire vel_sel3,
    output reg  tick_out
);

    reg [25:0] div_cnt;
	 
	 reg [2:0] Sel;

    reg [25:0] limite = 26'd49_999_999;

    always @(posedge clk or posedge rst) begin
	 Sel <= {vel_sel,vel_sel2,vel_sel3};
	 case (Sel)
	     3'b000: begin
			limite <= 26'd999;
			end
	     3'b001:begin
		  limite <= 26'd99_999;
		  end
	     3'b010:begin
		  limite <= 26'd1_999_999;
		  end
	     3'b011:begin
		  limite <= 26'd5_999_999;
		  end
	     3'b100:begin
		  limite <= 26'd9_999_999;
		  end
	     3'b101:begin
		  limite <= 26'd12_999_999;
		  end
	     3'b110:begin
		  limite <= 26'd25_999_999;
		  end
	     3'b111:begin
		  limite <= 26'd49_999_999;
		  end
		  endcase
		  
        if (rst) begin
            div_cnt  <= 26'd0;
            tick_out <= 1'b0;
        end
        else if (!en) begin
            div_cnt  <= 26'd0;
            tick_out <= 1'b0;
        end
        else if (div_cnt >= limite) begin
            div_cnt  <= 26'd0;
            tick_out <= 1'b1;
        end
        else begin
            div_cnt  <= div_cnt + 26'd1;
            tick_out <= 1'b0;
        end
    end

endmodule
