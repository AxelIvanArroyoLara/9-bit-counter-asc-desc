`timescale 1ns/1ps

module contador_fsm (
    input  wire              clk,
    input  wire              rst,
    input  wire              tick_in,
    input  wire              pausa_p,
    input  wire              sw_asc,
    input  wire              sw_desc,
    output reg signed [8:0]  valor,
    output reg [1:0]         estado
);

    localparam ST_PAUSA = 2'd0;
    localparam ST_ASC   = 2'd1;
    localparam ST_DESC  = 2'd2;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            valor  <= 9'sd0;
            estado <= ST_PAUSA;
        end
        else begin
            if (pausa_p)
                estado <= ST_PAUSA;
            else if (sw_asc)
                estado <= ST_ASC;
            else if (sw_desc)
                estado <= ST_DESC;

            if (tick_in) begin
                case (estado)
                    ST_ASC: begin
                        if (valor == 9'sd255)
                            valor <= -9'sd256;
                        else
                            valor <= valor + 9'sd1;
                    end

                    ST_DESC: begin
                        if (valor == -9'sd256)
                            valor <= 9'sd255;
                        else
                            valor <= valor - 9'sd1;
                    end

                    default: begin
                        valor <= valor;
                    end
                endcase
            end
        end
    end

endmodule
