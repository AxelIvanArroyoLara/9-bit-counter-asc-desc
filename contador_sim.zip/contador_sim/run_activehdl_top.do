alib work
alog -work work rtl/dec7seg.v rtl/display_9bit.v rtl/contador_fsm.v rtl/tick_gen.v rtl/debounce_pulse.v rtl/contador_top.v
alog -work work tb/tb_contador_top.v
asim +access +r work.tb_contador_top
wave /tb_contador_top/CLOCK_50
wave /tb_contador_top/KEY_RST_N
wave /tb_contador_top/KEY_PAUSA_N
wave /tb_contador_top/SW_VEL
wave /tb_contador_top/SW_ASC
wave /tb_contador_top/SW_DESC
wave /tb_contador_top/dut/tick_1
wave /tb_contador_top/dut/pausa_p
wave /tb_contador_top/dut/estado
wave /tb_contador_top/dut/valor
run -all
