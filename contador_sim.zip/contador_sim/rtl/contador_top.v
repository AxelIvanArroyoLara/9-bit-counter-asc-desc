`timescale 1ns/1ps

module contador_top #(
    parameter [25:0] LIM_LENTO  = 26'd49_999_999,
    parameter [25:0] LIM_RAPIDO = 26'd4_999_999,
    parameter [18:0] DB_LIMIT   = 19'd499_999
)(
    input  wire       CLOCK_50,
    input  wire       KEY_RST_N,
    input  wire       KEY_PAUSA_N,
    input  wire       SW_VEL,
    input  wire       SW_ASC,
    input  wire       SW_DESC,
    output wire [6:0] HEX0,
    output wire [6:0] HEX1,
    output wire [6:0] HEX2,
    output wire [6:0] HEX3,
    output wire [9:0] LEDR
);

    localparam [1:0] ST_PAUSA = 2'd0;
    localparam [1:0] ST_ASC   = 2'd1;
    localparam [1:0] ST_DESC  = 2'd2;

    wire              rst;
    wire              pausa_p;
    wire              tick_1;
    wire [1:0]        estado;
    wire signed [8:0] valor;
    wire              activo;

    assign rst    = ~KEY_RST_N;
    assign activo = (estado != ST_PAUSA);

    reg vel_m,  vel_s;
    reg asc_m,  asc_s;
    reg desc_m, desc_s;

    always @(posedge CLOCK_50 or posedge rst) begin
        if (rst) begin
            vel_m  <= 1'b0;
            vel_s  <= 1'b0;
            asc_m  <= 1'b0;
            asc_s  <= 1'b0;
            desc_m <= 1'b0;
            desc_s <= 1'b0;
        end
        else begin
            vel_m  <= SW_VEL;
            vel_s  <= vel_m;
            asc_m  <= SW_ASC;
            asc_s  <= asc_m;
            desc_m <= SW_DESC;
            desc_s <= desc_m;
        end
    end

    debounce_pulse #(.DB_LIMIT(DB_LIMIT)) u_pausa (
        .clk(CLOCK_50),
        .rst(rst),
        .btn_n(KEY_PAUSA_N),
        .pulse_out(pausa_p)
    );

    tick_gen #(.LIM_LENTO(LIM_LENTO), .LIM_RAPIDO(LIM_RAPIDO)) u_tick (
        .clk(CLOCK_50),
        .rst(rst),
        .en(activo),
        .vel_sel(vel_s),
        .tick_out(tick_1)
    );

    contador_fsm u_fsm (
        .clk(CLOCK_50),
        .rst(rst),
        .tick_in(tick_1),
        .pausa_p(pausa_p),
        .sw_asc(asc_s),
        .sw_desc(desc_s),
        .valor(valor),
        .estado(estado)
    );

    display_9bit u_disp (
        .dato(valor),
        .HEX0(HEX0),
        .HEX1(HEX1),
        .HEX2(HEX2),
        .HEX3(HEX3)
    );

    assign LEDR = {
        (valor < 0),
        5'b00000,
        vel_s,
        (estado == ST_DESC),
        (estado == ST_ASC),
        (estado == ST_PAUSA)
    };

endmodule
