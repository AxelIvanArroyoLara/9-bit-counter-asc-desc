`timescale 1ns/1ps

module debounce_pulse #(
    parameter [18:0] DB_LIMIT = 19'd499_999
)(
    input  wire clk,
    input  wire rst,
    input  wire btn_n,
    output reg  pulse_out
);

    reg [1:0]  sync_reg;
    reg        btn_estable;
    reg [18:0] db_cnt;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            sync_reg    <= 2'b11;
            btn_estable <= 1'b1;
            db_cnt      <= 19'd0;
            pulse_out   <= 1'b0;
        end
        else begin
            sync_reg  <= {sync_reg[0], btn_n};
            pulse_out <= 1'b0;

            if (sync_reg[1] == btn_estable) begin
                db_cnt <= 19'd0;
            end
            else if (db_cnt == DB_LIMIT) begin
                db_cnt      <= 19'd0;
                btn_estable <= sync_reg[1];

                if ((btn_estable == 1'b1) && (sync_reg[1] == 1'b0))
                    pulse_out <= 1'b1;
            end
            else begin
                db_cnt <= db_cnt + 19'd1;
            end
        end
    end

endmodule
