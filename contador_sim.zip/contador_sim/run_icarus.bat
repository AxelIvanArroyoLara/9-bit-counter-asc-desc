iverilog -g2005 -o sim_fsm tb/tb_contador_fsm.v rtl/contador_fsm.v rtl/display_9bit.v rtl/dec7seg.v
vvp sim_fsm
iverilog -g2005 -o sim_top tb/tb_contador_top.v rtl/contador_top.v rtl/contador_fsm.v rtl/display_9bit.v rtl/dec7seg.v rtl/debounce_pulse.v rtl/tick_gen.v
vvp sim_top
pause
