alib work
alog -work work rtl/dec7seg.v rtl/display_9bit.v rtl/contador_fsm.v
alog -work work tb/tb_contador_fsm.v
asim +access +r work.tb_contador_fsm
wave /tb_contador_fsm/clk
wave /tb_contador_fsm/rst
wave /tb_contador_fsm/tick_in
wave /tb_contador_fsm/sw_asc
wave /tb_contador_fsm/sw_desc
wave /tb_contador_fsm/pausa_p
wave /tb_contador_fsm/estado
wave /tb_contador_fsm/valor
wave /tb_contador_fsm/u_disp/centenas
wave /tb_contador_fsm/u_disp/decenas
wave /tb_contador_fsm/u_disp/unidades
run -all
