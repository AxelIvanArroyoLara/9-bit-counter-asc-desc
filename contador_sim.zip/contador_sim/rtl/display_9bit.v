`timescale 1ns/1ps

module display_9bit (
    input  wire signed [8:0] dato,
    output wire [6:0] HEX0,
    output wire [6:0] HEX1,
    output wire [6:0] HEX2,
    output wire [6:0] HEX3
);

    reg [8:0] magnitud;
    reg [3:0] centenas;
    reg [3:0] decenas;
    reg [3:0] unidades;

    always @(*) begin
        if (dato < 0)
            magnitud = -dato;
        else
            magnitud = dato;

        centenas = magnitud / 100;
        decenas  = (magnitud % 100) / 10;
        unidades = magnitud % 10;
    end

    dec7seg d0 (.bcd(unidades), .segs(HEX0));
    dec7seg d1 (.bcd(decenas),  .segs(HEX1));
    dec7seg d2 (.bcd(centenas), .segs(HEX2));

    assign HEX3 = (dato < 0) ? 7'b0111111 : 7'b1111111;

endmodule
